This is WorldClim 2.0 Beta version 1 (June 2016) downloaded from http://worldclim.org
They represent average monthly climate data for 1970-2000. 

The data were created by Steve Fick and Robert Hijmans
You are not allowed to redistribute these data. 
